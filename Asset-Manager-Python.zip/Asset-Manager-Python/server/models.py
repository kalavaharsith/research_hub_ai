"""
models.py — SQLAlchemy ORM models and Pydantic schemas.
Equivalent to shared/schema.ts (Drizzle ORM → SQLAlchemy + Pydantic).
"""

import uuid
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel
from sqlalchemy import (
    Column, String, Integer, Text, DateTime, ForeignKey, func
)
from sqlalchemy.orm import DeclarativeBase, relationship


# ─── SQLAlchemy Base ──────────────────────────────────────────────────────────

class Base(DeclarativeBase):
    pass


# ─── ORM Tables ───────────────────────────────────────────────────────────────

class User(Base):
    __tablename__ = "users"

    id: str = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    username: str = Column(Text, nullable=False, unique=True)
    password: str = Column(Text, nullable=False)

    sessions = relationship("ChatSession", back_populates="user", cascade="all, delete-orphan")


class ChatSession(Base):
    __tablename__ = "chat_sessions"

    id: int = Column(Integer, primary_key=True, autoincrement=True)
    user_id: str = Column(String, ForeignKey("users.id"), nullable=False)
    topic: str = Column(Text, nullable=False)
    created_at: datetime = Column(DateTime, server_default=func.now(), nullable=False)

    user = relationship("User", back_populates="sessions")
    messages = relationship("ChatMessage", back_populates="session", cascade="all, delete-orphan")


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id: int = Column(Integer, primary_key=True, autoincrement=True)
    session_id: int = Column(Integer, ForeignKey("chat_sessions.id", ondelete="CASCADE"), nullable=False)
    role: str = Column(Text, nullable=False)   # 'user' | 'assistant'
    content: str = Column(Text, nullable=False)
    created_at: datetime = Column(DateTime, server_default=func.now(), nullable=False)

    session = relationship("ChatSession", back_populates="messages")


# ─── Pydantic Schemas (request / response bodies) ────────────────────────────

class InsertUser(BaseModel):
    username: str
    password: str


class InsertChatSession(BaseModel):
    user_id: str
    topic: str


class InsertChatMessage(BaseModel):
    session_id: int
    role: str
    content: str


class UserResponse(BaseModel):
    id: str
    username: str

    model_config = {"from_attributes": True}


class ChatSessionResponse(BaseModel):
    id: int
    user_id: str
    topic: str
    created_at: datetime

    model_config = {"from_attributes": True}


class ChatMessageResponse(BaseModel):
    id: int
    session_id: int
    role: str
    content: str
    created_at: datetime

    model_config = {"from_attributes": True}


# ─── Research / Paper types ───────────────────────────────────────────────────

class PaperData(BaseModel):
    paperId: str
    title: str
    authors: List[str]
    year: int
    abstract: str
    url: str


class PaperExplanation(BaseModel):
    overview: str
    background: str
    keyConcepts: str
    applications: str
    references: str


class PaperDetail(PaperData):
    keywords: List[str]
    explanation: PaperExplanation


class ComparedPaper(BaseModel):
    title: str
    authors: List[str]
    year: int
    keyIdea: str
    methodology: str
    conclusion: str


class CompareResponse(BaseModel):
    papers: List[ComparedPaper]
