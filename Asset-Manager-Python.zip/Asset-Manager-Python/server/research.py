"""
research.py — Paper search & AI-powered explanation/comparison helpers.
Equivalent to server/research.ts.
"""

import re
import json
import random
from datetime import datetime
from typing import Any, Dict, List

import httpx
from openai import AsyncOpenAI


# ─── Paper Search ──────────────────────────────────────────────────────────────

async def search_papers(topic: str) -> List[Dict[str, Any]]:
    """Search Semantic Scholar first; fall back to arXiv on failure."""

    # --- Semantic Scholar -------------------------------------------------------
    try:
        url = (
            "https://api.semanticscholar.org/graph/v1/paper/search"
            f"?query={httpx.URL(topic).encode_query if False else topic}"
            "&fields=title,authors,year,abstract,externalIds,url,openAccessPdf"
            "&limit=10"
        )
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                "https://api.semanticscholar.org/graph/v1/paper/search",
                params={
                    "query": topic,
                    "fields": "title,authors,year,abstract,externalIds,url,openAccessPdf",
                    "limit": 10,
                },
            )
        resp.raise_for_status()
        data = resp.json()

        if data and data.get("data"):
            results = []
            for p in data["data"]:
                open_pdf = p.get("openAccessPdf") or {}
                corpus_id = (p.get("externalIds") or {}).get("CorpusId", "")
                results.append(
                    {
                        "paperId": p.get("paperId", ""),
                        "title": p.get("title") or "Untitled",
                        "authors": [a["name"] for a in (p.get("authors") or [])],
                        "year": p.get("year") or datetime.now().year,
                        "abstract": p.get("abstract") or "No abstract available.",
                        "url": p.get("url")
                        or open_pdf.get("url")
                        or f"https://api.semanticscholar.org/CorpusID:{corpus_id}",
                    }
                )
            return results
    except Exception as exc:
        print(f"Semantic Scholar API failed, falling back to arXiv: {exc}")

    # --- arXiv fallback --------------------------------------------------------
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                "https://export.arxiv.org/api/query",
                params={"search_query": f"all:{topic}", "start": 0, "max_results": 10},
            )
        xml = resp.text
        entries = re.findall(r"<entry>[\s\S]*?</entry>", xml)

        results = []
        for entry in entries:
            id_match = re.search(r"<id>(.*?)</id>", entry)
            title_match = re.search(r"<title>([\s\S]*?)</title>", entry)
            abstract_match = re.search(r"<summary>([\s\S]*?)</summary>", entry)
            year_match = re.search(r"<published>(\d{4})-[^<]*</published>", entry)
            author_matches = re.findall(r"<author>\s*<name>(.*?)</name>\s*</author>", entry)

            url = id_match.group(1).strip() if id_match else ""
            paper_id = url.split("/")[-1] if url else str(random.random())

            results.append(
                {
                    "paperId": paper_id,
                    "title": title_match.group(1).replace("\n", " ").strip() if title_match else "Untitled",
                    "authors": author_matches,
                    "year": int(year_match.group(1)) if year_match else datetime.now().year,
                    "abstract": abstract_match.group(1).strip() if abstract_match else "No abstract available.",
                    "url": url,
                }
            )
        return results
    except Exception as exc:
        print(f"arXiv fallback failed: {exc}")
        return []


# ─── Paper Details ─────────────────────────────────────────────────────────────

async def get_paper_details(paper_id: str) -> Dict[str, Any]:
    """Fetch a single paper by ID (Semantic Scholar or arXiv)."""

    # Semantic Scholar hash IDs are 40 hex chars
    if re.fullmatch(r"[0-9a-fA-F]{40}", paper_id):
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(
                f"https://api.semanticscholar.org/graph/v1/paper/{paper_id}",
                params={"fields": "title,authors,year,abstract,url,openAccessPdf"},
            )
        if resp.status_code == 200:
            p = resp.json()
            open_pdf = p.get("openAccessPdf") or {}
            return {
                "paperId": p.get("paperId", paper_id),
                "title": p.get("title") or "Untitled",
                "authors": [a["name"] for a in (p.get("authors") or [])],
                "year": p.get("year") or datetime.now().year,
                "abstract": p.get("abstract") or "No abstract available.",
                "url": p.get("url") or open_pdf.get("url") or "",
            }

    # arXiv
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(
            "https://export.arxiv.org/api/query",
            params={"id_list": paper_id},
        )
    xml = resp.text
    entry_match = re.search(r"<entry>[\s\S]*?</entry>", xml)
    if entry_match:
        e = entry_match.group(0)
        id_match = re.search(r"<id>(.*?)</id>", e)
        title_match = re.search(r"<title>([\s\S]*?)</title>", e)
        abstract_match = re.search(r"<summary>([\s\S]*?)</summary>", e)
        year_match = re.search(r"<published>(\d{4})-[^<]*</published>", e)
        authors = re.findall(r"<author>\s*<name>(.*?)</name>\s*</author>", e)
        url = id_match.group(1).strip() if id_match else ""

        return {
            "paperId": paper_id,
            "title": title_match.group(1).replace("\n", " ").strip() if title_match else "Untitled",
            "authors": authors,
            "year": int(year_match.group(1)) if year_match else datetime.now().year,
            "abstract": abstract_match.group(1).strip() if abstract_match else "No abstract available.",
            "url": url,
        }

    raise ValueError("Paper not found")


# ─── AI Helpers ───────────────────────────────────────────────────────────────

async def generate_paper_explanation(
    openai_client: AsyncOpenAI, title: str, abstract: str
) -> Dict[str, Any]:
    """Generate a structured Wikipedia-style explanation for a paper."""

    prompt = f"""You are a research assistant. Generate a structured Wikipedia-style explanation for this academic paper.
Title: {title}
Abstract: {abstract}

Output ONLY a JSON object with these EXACT keys:
{{
  "overview": "string",
  "background": "string",
  "keyConcepts": "string",
  "applications": "string",
  "references": "string"
}}"""

    response = await openai_client.chat.completions.create(
        model="gpt-5.1",
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"},
    )
    return json.loads(response.choices[0].message.content or "{}")


async def generate_comparison(
    openai_client: AsyncOpenAI, papers: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """Compare multiple papers and return structured analysis."""

    papers_text = "\n\n".join(
        f"Title: {p['title']}\nAbstract: {p['abstract']}" for p in papers
    )
    prompt = f"""You are a research assistant. Compare the following papers.
{papers_text}

Output ONLY a JSON object with a single key "papers" containing an array of objects in the EXACT same order.
Each object must have these EXACT keys:
{{
  "keyIdea": "string",
  "methodology": "string",
  "conclusion": "string"
}}"""

    response = await openai_client.chat.completions.create(
        model="gpt-5.1",
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object"},
    )
    return json.loads(response.choices[0].message.content or '{"papers": []}')
