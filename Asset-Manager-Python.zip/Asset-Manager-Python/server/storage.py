"""
storage.py — Database access layer (CRUD).
Equivalent to server/storage.ts (DatabaseStorage class).
"""

from typing import List, Optional

from sqlalchemy.orm import Session

from server.models import (
    User, ChatSession, ChatMessage,
    InsertUser, InsertChatSession, InsertChatMessage,
)


class DatabaseStorage:
    # ── Users ─────────────────────────────────────────────────────────────────

    def get_user(self, db: Session, user_id: str) -> Optional[User]:
        return db.query(User).filter(User.id == user_id).first()

    def get_user_by_username(self, db: Session, username: str) -> Optional[User]:
        return db.query(User).filter(User.username == username).first()

    def create_user(self, db: Session, data: InsertUser) -> User:
        user = User(username=data.username, password=data.password)
        db.add(user)
        db.commit()
        db.refresh(user)
        return user

    # ── Chat Sessions ──────────────────────────────────────────────────────────

    def get_chat_sessions(self, db: Session, user_id: str) -> List[ChatSession]:
        return db.query(ChatSession).filter(ChatSession.user_id == user_id).all()

    def get_chat_session(self, db: Session, session_id: int) -> Optional[ChatSession]:
        return db.query(ChatSession).filter(ChatSession.id == session_id).first()

    def create_chat_session(self, db: Session, data: InsertChatSession) -> ChatSession:
        session = ChatSession(user_id=data.user_id, topic=data.topic)
        db.add(session)
        db.commit()
        db.refresh(session)
        return session

    # ── Chat Messages ──────────────────────────────────────────────────────────

    def get_chat_messages(self, db: Session, session_id: int) -> List[ChatMessage]:
        return db.query(ChatMessage).filter(ChatMessage.session_id == session_id).all()

    def create_chat_message(self, db: Session, data: InsertChatMessage) -> ChatMessage:
        message = ChatMessage(
            session_id=data.session_id,
            role=data.role,
            content=data.content,
        )
        db.add(message)
        db.commit()
        db.refresh(message)
        return message


# Singleton instance (mirrors `export const storage = new DatabaseStorage()`)
storage = DatabaseStorage()
