"""
routes.py — All API route handlers.
Equivalent to server/routes.ts (Express → FastAPI).

Session management: itsdangerous-signed cookies via Starlette's SessionMiddleware.
"""

import os
import json
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from openai import AsyncOpenAI
from sqlalchemy.orm import Session

from server.db import get_db
from server.storage import storage
from server.models import (
    InsertUser, InsertChatSession, InsertChatMessage,
    UserResponse, ChatSessionResponse, ChatMessageResponse,
)
from server.research import (
    search_papers, get_paper_details,
    generate_paper_explanation, generate_comparison,
)

router = APIRouter()

# ─── OpenAI Client ────────────────────────────────────────────────────────────

openai_client = AsyncOpenAI(
    api_key=os.getenv("AI_INTEGRATIONS_OPENAI_API_KEY"),
    base_url=os.getenv("AI_INTEGRATIONS_OPENAI_BASE_URL"),
)


# ─── Auth helper ──────────────────────────────────────────────────────────────

def get_current_user_id(request: Request) -> str:
    """Extract user_id from the session; raise 401 if absent."""
    user_id = request.session.get("userId")
    if not user_id:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return user_id


# ─── Request / Response models ────────────────────────────────────────────────

class LoginRequest(BaseModel):
    username: str
    password: str


class CreateSessionRequest(BaseModel):
    message: str


class SendMessageRequest(BaseModel):
    message: str


class CompareRequest(BaseModel):
    paperIds: List[str]


# ─── Auth Routes ──────────────────────────────────────────────────────────────

@router.post("/api/auth/login")
async def login(body: LoginRequest, request: Request, db: Session = Depends(get_db)):
    user = storage.get_user_by_username(db, body.username)
    if not user or user.password != body.password:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    request.session["userId"] = user.id
    return {"id": user.id, "username": user.username}


@router.post("/api/auth/signup", status_code=201)
async def signup(body: LoginRequest, request: Request, db: Session = Depends(get_db)):
    existing = storage.get_user_by_username(db, body.username)
    if existing:
        raise HTTPException(status_code=400, detail="Username taken")
    user = storage.create_user(db, InsertUser(username=body.username, password=body.password))
    request.session["userId"] = user.id
    return {"id": user.id, "username": user.username}


@router.post("/api/auth/logout")
async def logout(request: Request):
    request.session.clear()
    return {"message": "Logged out"}


@router.get("/api/auth/me")
async def me(request: Request, db: Session = Depends(get_db)):
    user_id = request.session.get("userId")
    if not user_id:
        raise HTTPException(status_code=401, detail="Not logged in")
    user = storage.get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return {"id": user.id, "username": user.username}


# ─── Research Routes ──────────────────────────────────────────────────────────

@router.get("/api/search")
async def search(
    query: str = "",
    user_id: str = Depends(get_current_user_id),
):
    if not query:
        return []
    results = await search_papers(query)
    return results


@router.get("/api/paper/{paper_id}")
async def paper_detail(
    paper_id: str,
    user_id: str = Depends(get_current_user_id),
):
    try:
        paper_data = await get_paper_details(paper_id)
        explanation = await generate_paper_explanation(
            openai_client, paper_data["title"], paper_data["abstract"]
        )
        keywords = (
            [k.strip() for k in explanation.get("keyConcepts", "").split(",")]
            if explanation.get("keyConcepts")
            else []
        )
        return {**paper_data, "keywords": keywords, "explanation": explanation}
    except Exception:
        raise HTTPException(status_code=404, detail="Paper not found or error fetching details")


@router.post("/api/compare")
async def compare(
    body: CompareRequest,
    user_id: str = Depends(get_current_user_id),
):
    try:
        papers_data = []
        for pid in body.paperIds:
            papers_data.append(await get_paper_details(pid))

        comp_res = await generate_comparison(openai_client, papers_data)

        final_comparison = [
            {
                "title": p["title"],
                "authors": p["authors"],
                "year": p["year"],
                "keyIdea": (comp_res.get("papers") or [{}])[i].get("keyIdea", "") if i < len(comp_res.get("papers") or []) else "",
                "methodology": (comp_res.get("papers") or [{}])[i].get("methodology", "") if i < len(comp_res.get("papers") or []) else "",
                "conclusion": (comp_res.get("papers") or [{}])[i].get("conclusion", "") if i < len(comp_res.get("papers") or []) else "",
            }
            for i, p in enumerate(papers_data)
        ]
        return {"papers": final_comparison}
    except Exception:
        raise HTTPException(status_code=500, detail="Comparison failed")


# ─── Chat Routes ──────────────────────────────────────────────────────────────

@router.get("/api/chat/sessions")
async def get_sessions(
    request: Request,
    db: Session = Depends(get_db),
    user_id: str = Depends(get_current_user_id),
):
    sessions = storage.get_chat_sessions(db, user_id)
    return [
        {
            "id": s.id,
            "userId": s.user_id,
            "topic": s.topic,
            "createdAt": s.created_at.isoformat(),
        }
        for s in sessions
    ]


@router.post("/api/chat/sessions", status_code=201)
async def create_session(
    body: CreateSessionRequest,
    request: Request,
    db: Session = Depends(get_db),
    user_id: str = Depends(get_current_user_id),
):
    try:
        topic_res = await openai_client.chat.completions.create(
            model="gpt-5.1",
            messages=[
                {
                    "role": "user",
                    "content": f"Generate a 3-5 word topic for this research query: {body.message}",
                }
            ],
        )
        topic = (topic_res.choices[0].message.content or "New Research Chat").strip().strip("'\"")

        session = storage.create_chat_session(
            db, InsertChatSession(user_id=user_id, topic=topic)
        )
        storage.create_chat_message(
            db,
            InsertChatMessage(session_id=session.id, role="user", content=body.message),
        )
        return {
            "session": {
                "id": session.id,
                "userId": session.user_id,
                "topic": session.topic,
                "createdAt": session.created_at.isoformat(),
            }
        }
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to create session")


@router.get("/api/chat/sessions/{session_id}")
async def get_session(
    session_id: int,
    request: Request,
    db: Session = Depends(get_db),
    user_id: str = Depends(get_current_user_id),
):
    session = storage.get_chat_session(db, session_id)
    if not session or session.user_id != user_id:
        raise HTTPException(status_code=404, detail="Not found")
    messages = storage.get_chat_messages(db, session_id)
    return {
        "session": {
            "id": session.id,
            "userId": session.user_id,
            "topic": session.topic,
            "createdAt": session.created_at.isoformat(),
        },
        "messages": [
            {
                "id": m.id,
                "sessionId": m.session_id,
                "role": m.role,
                "content": m.content,
                "createdAt": m.created_at.isoformat(),
            }
            for m in messages
        ],
    }


@router.post("/api/chat/sessions/{session_id}/messages")
async def send_message(
    session_id: int,
    body: SendMessageRequest,
    request: Request,
    db: Session = Depends(get_db),
    user_id: str = Depends(get_current_user_id),
):
    session = storage.get_chat_session(db, session_id)
    if not session or session.user_id != user_id:
        raise HTTPException(status_code=404, detail="Not found")

    storage.create_chat_message(
        db,
        InsertChatMessage(session_id=session_id, role="user", content=body.message),
    )

    messages = storage.get_chat_messages(db, session_id)
    chat_history = [{"role": m.role, "content": m.content} for m in messages]

    system_prompt = (
        "You are a research assistant for the Cognix platform. "
        "Answer only research-related questions. Provide structured, factual, "
        "academic-style responses. Do not engage in casual conversation. "
        "Cite relevant concepts."
    )

    async def event_stream():
        full_content = ""
        try:
            stream = await openai_client.chat.completions.create(
                model="gpt-5.1",
                messages=[{"role": "system", "content": system_prompt}, *chat_history],
                stream=True,
            )
            async for chunk in stream:
                content = (chunk.choices[0].delta.content or "") if chunk.choices else ""
                if content:
                    full_content += content
                    yield f"data: {json.dumps({'content': content})}\n\n"

            # Persist assistant message after stream completes
            storage.create_chat_message(
                db,
                InsertChatMessage(
                    session_id=session_id, role="assistant", content=full_content
                ),
            )
            yield f"data: {json.dumps({'done': True})}\n\n"
        except Exception as exc:
            print(exc)
            yield f"data: {json.dumps({'error': 'Failed to stream response'})}\n\n"

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )
