"""
main.py — Application entry point.
Equivalent to server/index.ts (Express → FastAPI/Uvicorn).

Run with:
    python main.py
    # or
    uvicorn main:app --host 0.0.0.0 --port 5000 --reload
"""

import os
import time
import logging
from datetime import datetime

from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from starlette.middleware.sessions import SessionMiddleware

load_dotenv()

from server.db import create_tables
from server.routes import router

# ─── Logging ──────────────────────────────────────────────────────────────────

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("uvicorn")


def log(message: str, source: str = "fastapi") -> None:
    now = datetime.now().strftime("%I:%M:%S %p")
    print(f"{now} [{source}] {message}")


# ─── App setup ────────────────────────────────────────────────────────────────

app = FastAPI(title="Cognix Backend")

# Session middleware (equivalent to express-session + MemoryStore)
app.add_middleware(
    SessionMiddleware,
    secret_key=os.getenv("SESSION_SECRET", "cognix_secret"),
    session_cookie="session",
    max_age=86400,          # 1 day
    same_site="lax",
    https_only=False,       # Set True in production with HTTPS
)

# ─── Request logging middleware ───────────────────────────────────────────────

@app.middleware("http")
async def request_logger(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    duration_ms = int((time.time() - start) * 1000)

    if request.url.path.startswith("/api"):
        log(f"{request.method} {request.url.path} {response.status_code} in {duration_ms}ms")

    return response


# ─── Global error handler ─────────────────────────────────────────────────────

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Internal Server Error: {exc}", exc_info=True)
    return JSONResponse(status_code=500, content={"message": "Internal Server Error"})


# ─── Routes ───────────────────────────────────────────────────────────────────

app.include_router(router)


# ─── Static files (production) ────────────────────────────────────────────────

if os.getenv("NODE_ENV") == "production":
    import pathlib
    from fastapi.staticfiles import StaticFiles
    from fastapi.responses import FileResponse

    dist_path = pathlib.Path(__file__).parent / "public"
    if not dist_path.exists():
        raise RuntimeError(
            f"Could not find the build directory: {dist_path}, "
            "make sure to build the client first"
        )

    app.mount("/assets", StaticFiles(directory=str(dist_path / "assets")), name="assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        """Catch-all — serve index.html for client-side routing."""
        return FileResponse(str(dist_path / "index.html"))


# ─── Startup event ────────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    create_tables()
    log("Database tables ensured")


# ─── Dev entrypoint ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    port = int(os.getenv("PORT", "5000"))
    log(f"serving on port {port}")
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
