import { createContext, useContext, useState, ReactNode } from "react";
import { PaperData } from "@shared/schema";

interface ComparisonContextType {
  selectedPapers: PaperData[];
  togglePaper: (paper: PaperData) => void;
  clearComparison: () => void;
  isSelected: (paperId: string) => boolean;
}

const ComparisonContext = createContext<ComparisonContextType | null>(null);

export function ComparisonProvider({ children }: { children: ReactNode }) {
  const [selectedPapers, setSelectedPapers] = useState<PaperData[]>([]);

  const togglePaper = (paper: PaperData) => {
    setSelectedPapers((prev) => {
      const exists = prev.find((p) => p.paperId === paper.paperId);
      if (exists) {
        return prev.filter((p) => p.paperId !== paper.paperId);
      } else {
        return [...prev, paper];
      }
    });
  };

  const clearComparison = () => setSelectedPapers([]);

  const isSelected = (paperId: string) => 
    selectedPapers.some((p) => p.paperId === paperId);

  return (
    <ComparisonContext.Provider value={{ selectedPapers, togglePaper, clearComparison, isSelected }}>
      {children}
    </ComparisonContext.Provider>
  );
}

export function useComparison() {
  const context = useContext(ComparisonContext);
  if (!context) throw new Error("useComparison must be used within a ComparisonProvider");
  return context;
}
