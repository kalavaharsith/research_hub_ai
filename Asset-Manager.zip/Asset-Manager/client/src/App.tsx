import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { AuthProvider, useAuth } from "./hooks/use-auth";
import { ComparisonProvider } from "./context/comparison-context";
import { Layout } from "./components/layout";
import { Spinner } from "./components/ui/spinner";

import Login from "./pages/login";
import Home from "./pages/home";
import PaperDetail from "./pages/paper";
import Compare from "./pages/compare";
import Chat from "./pages/chat";

// Protected Route wrapper
function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="h-screen w-full flex items-center justify-center bg-background">
      <Spinner className="w-10 h-10 text-primary" />
    </div>;
  }
  
  if (!user) {
    window.location.href = "/login";
    return null;
  }

  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      
      {/* Protected Routes wrapped in Layout inside App Structure */}
      <Route path="/">
        <ProtectedRoute component={Home} />
      </Route>
      <Route path="/paper/:id">
        <ProtectedRoute component={PaperDetail} />
      </Route>
      <Route path="/compare">
        <ProtectedRoute component={Compare} />
      </Route>
      <Route path="/chat/:id">
        <ProtectedRoute component={Chat} />
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <ComparisonProvider>
            <Toaster />
            <Layout>
              <Router />
            </Layout>
          </ComparisonProvider>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
