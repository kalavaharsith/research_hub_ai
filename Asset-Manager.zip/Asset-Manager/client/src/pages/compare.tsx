import { useComparison } from "@/context/comparison-context";
import { useCompare } from "@/hooks/use-research";
import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { ArrowLeft, Trash2, SplitSquareHorizontal } from "lucide-react";
import { Spinner } from "@/components/ui/spinner";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

export default function Compare() {
  const { selectedPapers, clearComparison } = useComparison();
  const { mutate: comparePapers, isPending, data: comparison, error } = useCompare();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (selectedPapers.length >= 2 && !comparison && !isPending && !error) {
      comparePapers(selectedPapers.map(p => p.paperId));
    }
  }, [selectedPapers, comparison, isPending, error, comparePapers]);

  if (selectedPapers.length < 2) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center">
        <SplitSquareHorizontal className="w-16 h-16 text-muted-foreground mb-4 opacity-50" />
        <h2 className="text-2xl font-serif font-bold text-foreground mb-2">Not enough papers</h2>
        <p className="text-muted-foreground mb-6">Select at least 2 papers from the search to compare them.</p>
        <Link href="/">
          <button className="px-6 py-2 bg-primary text-primary-foreground rounded-lg font-medium shadow-md">
            Go to Search
          </button>
        </Link>
      </div>
    );
  }

  const handleClear = () => {
    clearComparison();
    setLocation("/");
  };

  return (
    <div className="max-w-[1400px] mx-auto px-6 py-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <Link href="/">
            <button className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors mb-2">
              <ArrowLeft className="w-4 h-4" />
              Back to Search
            </button>
          </Link>
          <h1 className="text-3xl font-serif font-bold text-foreground">Compare Papers</h1>
        </div>
        <button 
          onClick={handleClear}
          className="flex items-center gap-2 px-4 py-2 bg-destructive/10 text-destructive rounded-lg text-sm font-medium hover:bg-destructive hover:text-destructive-foreground transition-colors"
        >
          <Trash2 className="w-4 h-4" />
          Clear Comparison
        </button>
      </div>

      {isPending ? (
        <div className="academic-card p-12 flex flex-col items-center justify-center">
          <Spinner className="w-10 h-10 text-primary mb-6" />
          <h3 className="text-xl font-serif font-medium text-foreground mb-2">Cognix AI is analyzing...</h3>
          <p className="text-muted-foreground">Extracting methodologies, key ideas, and synthesising a comparison matrix.</p>
        </div>
      ) : error ? (
        <div className="academic-card p-12 text-center text-destructive border-destructive/20 bg-destructive/5">
          <p>Failed to generate comparison. Please try again with different papers.</p>
        </div>
      ) : comparison ? (
        <div className="overflow-x-auto pb-8">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr>
                <th className="p-4 w-48 bg-muted/50 border-b-2 border-border font-serif text-muted-foreground align-bottom">
                  Criteria
                </th>
                {comparison.papers.map((paper, i) => (
                  <th key={i} className="p-4 min-w-[350px] border-b-2 border-border align-top bg-card">
                    <div className="text-xs font-bold text-primary mb-2 uppercase tracking-widest">Paper {i+1}</div>
                    <div className="font-serif font-bold text-lg leading-tight mb-2 text-foreground">
                      {paper.title}
                    </div>
                    <div className="text-sm font-medium text-muted-foreground">
                      {paper.authors.slice(0, 3).join(", ")} {paper.authors.length > 3 && "et al."} ({paper.year})
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              <tr>
                <td className="p-4 font-semibold text-foreground bg-muted/30 align-top">Key Idea</td>
                {comparison.papers.map((p, i) => (
                  <td key={i} className="p-4 align-top prose-academic bg-card">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{p.keyIdea}</ReactMarkdown>
                  </td>
                ))}
              </tr>
              <tr>
                <td className="p-4 font-semibold text-foreground bg-muted/30 align-top">Methodology</td>
                {comparison.papers.map((p, i) => (
                  <td key={i} className="p-4 align-top prose-academic bg-card">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{p.methodology}</ReactMarkdown>
                  </td>
                ))}
              </tr>
              <tr>
                <td className="p-4 font-semibold text-foreground bg-muted/30 align-top">Conclusion</td>
                {comparison.papers.map((p, i) => (
                  <td key={i} className="p-4 align-top prose-academic bg-card">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>{p.conclusion}</ReactMarkdown>
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>
      ) : null}
    </div>
  );
}
