import { useState, useEffect } from "react";
import { useSearch } from "@/hooks/use-research";
import { useComparison } from "@/context/comparison-context";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import { Search, FileText, CheckCircle2, ChevronRight } from "lucide-react";
import { Spinner } from "@/components/ui/spinner";
import { useAuth } from "@/hooks/use-auth";

export default function Home() {
  const { user } = useAuth();
  const [searchInput, setSearchInput] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");
  const { data: results, isLoading, isError } = useSearch(debouncedQuery);
  const { togglePaper, isSelected } = useComparison();

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(searchInput);
    }, 600);
    return () => clearTimeout(timer);
  }, [searchInput]);

  return (
    <div className="min-h-full max-w-5xl mx-auto px-6 py-12 md:py-20 flex flex-col">
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className={`w-full max-w-2xl mx-auto transition-all duration-700 ease-in-out ${debouncedQuery ? 'mt-0' : 'mt-32'}`}
      >
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-serif font-semibold tracking-tight text-foreground mb-4">
            What do you want to research?
          </h1>
          <p className="text-lg text-muted-foreground">
            Search millions of papers. Cognix AI will break them down for you.
          </p>
        </div>

        <div className="relative group shadow-lg shadow-black/5 rounded-2xl">
          <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none text-muted-foreground group-focus-within:text-primary transition-colors">
            <Search className="h-6 w-6" />
          </div>
          <input
            type="text"
            className="block w-full pl-14 pr-6 py-5 bg-card border-2 border-border/50 rounded-2xl text-lg font-medium text-foreground placeholder:text-muted-foreground placeholder:font-normal focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all"
            placeholder="E.g., Quantum computing in neural networks..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
          />
        </div>
      </motion.div>

      <AnimatePresence mode="wait">
        {isLoading && (
          <motion.div 
            key="loading"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex flex-col items-center justify-center mt-24 text-muted-foreground"
          >
            <Spinner className="w-8 h-8 text-primary mb-4" />
            <p>Searching academic databases...</p>
          </motion.div>
        )}

        {isError && (
          <motion.div 
            key="error"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="text-center mt-24 text-destructive"
          >
            <p>Something went wrong searching. Please try again.</p>
          </motion.div>
        )}

        {results && results.length > 0 && !isLoading && (
          <motion.div 
            key="results"
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="mt-16 space-y-6"
          >
            <h3 className="font-medium text-muted-foreground flex items-center gap-2 border-b pb-3">
              <FileText className="w-4 h-4" />
              Found {results.length} results
            </h3>
            
            <div className="grid gap-6">
              {results.map((paper, index) => (
                <motion.div 
                  key={paper.paperId}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="academic-card p-6 flex flex-col sm:flex-row gap-6 relative group"
                >
                  <div className="flex-1 space-y-3">
                    <div className="flex items-start justify-between gap-4">
                      <Link href={`/paper/${paper.paperId}`}>
                        <h2 className="text-xl font-serif font-bold text-foreground leading-tight hover:text-primary transition-colors cursor-pointer group-hover:underline decoration-primary/30 underline-offset-4">
                          {paper.title}
                        </h2>
                      </Link>
                      <span className="shrink-0 bg-secondary text-secondary-foreground text-xs font-semibold px-2.5 py-1 rounded-md">
                        {paper.year}
                      </span>
                    </div>
                    
                    <p className="text-sm text-primary/80 font-medium">
                      {paper.authors.slice(0, 5).join(", ")}
                      {paper.authors.length > 5 && " et al."}
                    </p>
                    
                    <p className="text-muted-foreground text-sm leading-relaxed line-clamp-3">
                      {paper.abstract}
                    </p>
                  </div>

                  <div className="flex sm:flex-col justify-end gap-3 sm:w-48 shrink-0 sm:border-l sm:pl-6 border-border/50">
                    <button 
                      onClick={() => togglePaper(paper)}
                      className={`w-full py-2 px-3 rounded-lg text-sm font-medium border flex items-center justify-center gap-2 transition-all ${
                        isSelected(paper.paperId) 
                        ? 'bg-primary/10 border-primary/30 text-primary' 
                        : 'bg-transparent border-border hover:border-primary/50 text-foreground'
                      }`}
                    >
                      {isSelected(paper.paperId) ? (
                        <><CheckCircle2 className="w-4 h-4" /> Selected</>
                      ) : (
                        "Compare"
                      )}
                    </button>
                    
                    <Link href={`/paper/${paper.paperId}`}>
                      <button className="w-full py-2 px-3 bg-primary text-primary-foreground rounded-lg text-sm font-medium shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2">
                        View Details <ChevronRight className="w-4 h-4" />
                      </button>
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
