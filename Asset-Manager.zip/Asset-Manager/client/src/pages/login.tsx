import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { Spinner } from "@/components/ui/spinner";
import { useLocation } from "wouter";

export default function Login() {
  const { login, signup, isLoginPending, isSignupPending, user } = useAuth();
  const [, setLocation] = useLocation();
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  // Redirect if already logged in — use effect to avoid state update during render
  useEffect(() => {
    if (user) setLocation("/");
  }, [user, setLocation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLogin) {
      login({ username, password });
    } else {
      signup({ username, password });
    }
  };

  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-2 bg-background">
      <div className="flex items-center justify-center p-8 lg:p-12 z-10 relative">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md space-y-8"
        >
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center font-serif font-bold text-2xl shadow-lg">
                C
              </div>
              <span className="font-serif font-bold text-3xl tracking-tight">Cognix</span>
            </div>
            <h1 className="text-3xl font-serif font-semibold text-foreground tracking-tight">
              {isLogin ? "Welcome back" : "Create an account"}
            </h1>
            <p className="mt-3 text-muted-foreground text-lg">
              {isLogin 
                ? "Sign in to access your research history and AI tools." 
                : "Join to discover and analyze academic papers faster."}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5 mt-8">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground" htmlFor="username">
                Username
              </label>
              <input
                id="username"
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-white border border-border/50 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all duration-200 shadow-sm"
                placeholder="Enter your username"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground" htmlFor="password">
                Password
              </label>
              <input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-white border border-border/50 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all duration-200 shadow-sm"
                placeholder="••••••••"
              />
            </div>
            
            <button
              type="submit"
              disabled={isLoginPending || isSignupPending}
              className="w-full py-3.5 px-4 bg-primary text-primary-foreground rounded-xl font-medium shadow-lg shadow-primary/20 hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 disabled:opacity-70 flex items-center justify-center"
            >
              {isLoginPending || isSignupPending ? (
                <Spinner className="mr-2" />
              ) : null}
              {isLogin ? "Sign In" : "Sign Up"}
            </button>
          </form>

          <p className="text-center text-sm text-muted-foreground pt-4">
            {isLogin ? "Don't have an account? " : "Already have an account? "}
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="font-medium text-primary hover:underline underline-offset-4"
            >
              {isLogin ? "Sign up" : "Sign in"}
            </button>
          </p>
        </motion.div>
      </div>

      <div className="hidden lg:block relative bg-slate-900 overflow-hidden">
        {/* Abstract background for academic feel */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 z-0"></div>
        <div className="absolute inset-0 opacity-20 z-0" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '40px 40px' }}></div>
        
        <div className="absolute inset-0 flex items-center justify-center z-10 p-16 text-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-lg"
          >
            <h2 className="text-4xl font-serif text-white mb-6 leading-tight">
              Accelerate your academic discovery.
            </h2>
            <p className="text-lg text-slate-300 leading-relaxed">
              Cognix integrates intelligent search with AI-driven analysis to help you understand complex papers faster, compare methodologies side-by-side, and synthesize information effortlessly.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
