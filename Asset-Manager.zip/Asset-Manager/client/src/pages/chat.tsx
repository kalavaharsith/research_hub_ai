import { useParams } from "wouter";
import { useSession, useChatStream } from "@/hooks/use-chat";
import { useState, useRef, useEffect } from "react";
import { Send, Bot, User as UserIcon } from "lucide-react";
import { Spinner } from "@/components/ui/spinner";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

export default function Chat() {
  const { id } = useParams();
  const sessionId = parseInt(id || "0");
  const { data, isLoading } = useSession(sessionId);
  const { sendMessage, isStreaming, streamingContent } = useChatStream(sessionId);
  
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [data?.messages, streamingContent]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isStreaming) return;
    
    sendMessage(input);
    setInput("");
  };

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner className="w-8 h-8 text-primary" />
      </div>
    );
  }

  if (!data) return <div className="p-8 text-center">Session not found.</div>;

  return (
    <div className="flex flex-col h-full bg-background relative">
      <div className="p-4 md:p-6 border-b border-border/50 bg-card/80 backdrop-blur-md sticky top-0 z-10 shadow-sm">
        <h2 className="text-xl font-serif font-bold text-foreground">{data.session.topic}</h2>
        <p className="text-xs text-muted-foreground">Research Assistant</p>
      </div>

      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        {data.messages.length === 0 && !isStreaming && (
          <div className="flex flex-col items-center justify-center h-full text-center max-w-md mx-auto">
            <Bot className="w-12 h-12 text-primary/40 mb-4" />
            <h3 className="text-xl font-serif font-semibold mb-2">How can I assist your research?</h3>
            <p className="text-muted-foreground text-sm">
              Ask me to summarize specific concepts, suggest related papers, or explain complex methodologies.
            </p>
          </div>
        )}

        {data.messages.map((msg: any) => (
          <div 
            key={msg.id} 
            className={`flex gap-4 max-w-4xl mx-auto ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
              msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-secondary text-secondary-foreground'
            }`}>
              {msg.role === 'user' ? <UserIcon className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>
            
            <div className={`rounded-2xl px-5 py-4 max-w-[85%] ${
              msg.role === 'user' 
              ? 'bg-primary text-primary-foreground rounded-tr-sm' 
              : 'bg-card border border-border shadow-sm rounded-tl-sm prose-academic'
            }`}>
              {msg.role === 'user' ? (
                <p className="whitespace-pre-wrap text-sm leading-relaxed">{msg.content}</p>
              ) : (
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{msg.content}</ReactMarkdown>
              )}
            </div>
          </div>
        ))}

        {isStreaming && (
          <div className="flex gap-4 max-w-4xl mx-auto">
            <div className="w-8 h-8 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4" />
            </div>
            <div className="bg-card border border-border shadow-sm rounded-2xl rounded-tl-sm px-5 py-4 max-w-[85%] prose-academic min-w-[60px]">
              {streamingContent ? (
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{streamingContent}</ReactMarkdown>
              ) : (
                <div className="flex gap-1 items-center h-5">
                  <span className="w-1.5 h-1.5 bg-primary/50 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-1.5 h-1.5 bg-primary/50 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-1.5 h-1.5 bg-primary/50 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
              )}
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 md:p-6 bg-background border-t border-border/50">
        <form onSubmit={handleSubmit} className="max-w-4xl mx-auto relative group">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isStreaming}
            placeholder="Ask about your research..."
            className="w-full bg-card border-2 border-border rounded-xl pl-5 pr-14 py-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all disabled:opacity-70 shadow-sm"
          />
          <button
            type="submit"
            disabled={!input.trim() || isStreaming}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 bg-primary text-primary-foreground rounded-lg flex items-center justify-center hover:bg-primary/90 disabled:opacity-50 disabled:hover:bg-primary transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
