import { useParams } from "wouter";
import { usePaper } from "@/hooks/use-research";
import { useComparison } from "@/context/comparison-context";
import { Link } from "wouter";
import { ArrowLeft, ExternalLink, Scale, CheckCircle2, BookOpen } from "lucide-react";
import { Spinner } from "@/components/ui/spinner";
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

export default function PaperDetail() {
  const { id } = useParams();
  const { data: paper, isLoading, isError } = usePaper(id!);
  const { togglePaper, isSelected } = useComparison();

  if (isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner className="w-8 h-8 text-primary" />
      </div>
    );
  }

  if (isError || !paper) {
    return (
      <div className="p-8 text-center">
        <h2 className="text-xl font-serif text-destructive">Failed to load paper details.</h2>
        <Link href="/">
          <button className="mt-4 text-primary hover:underline">Return Home</button>
        </Link>
      </div>
    );
  }

  const selected = isSelected(paper.paperId);

  return (
    <div className="max-w-6xl mx-auto px-6 py-8 pb-32">
      <div className="mb-6 flex items-center justify-between">
        <Link href="/">
          <button className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Back to Search
          </button>
        </Link>
        <div className="flex gap-3">
          <button 
            onClick={() => togglePaper(paper)}
            className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-all ${
              selected 
              ? 'bg-primary border-primary text-primary-foreground shadow-md' 
              : 'bg-card border border-border hover:bg-muted text-foreground'
            }`}
          >
            {selected ? <CheckCircle2 className="w-4 h-4" /> : <Scale className="w-4 h-4" />}
            {selected ? "Selected for Comparison" : "Select for Comparison"}
          </button>
          {paper.url && (
            <a 
              href={paper.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-4 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground hover:bg-muted transition-colors flex items-center gap-2"
            >
              <ExternalLink className="w-4 h-4" />
              View Source
            </a>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        {/* Left Column: Metadata & Abstract */}
        <div className="lg:col-span-1 space-y-8">
          <div>
            <div className="inline-block px-3 py-1 bg-primary/10 text-primary font-semibold text-xs rounded-full mb-4">
              Published {paper.year}
            </div>
            <h1 className="text-3xl font-serif font-bold text-foreground leading-tight mb-4">
              {paper.title}
            </h1>
            <div className="text-base text-primary/80 font-medium leading-relaxed">
              {paper.authors.join(", ")}
            </div>
          </div>

          {paper.keywords && paper.keywords.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-3">Keywords</h3>
              <div className="flex flex-wrap gap-2">
                {paper.keywords.map(kw => (
                  <span key={kw} className="px-2.5 py-1 bg-secondary text-secondary-foreground text-xs font-medium rounded-md">
                    {kw}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="bg-card border border-border/50 rounded-xl p-6 shadow-sm">
            <h3 className="font-serif text-xl font-semibold mb-4 text-foreground">Abstract</h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              {paper.abstract}
            </p>
          </div>
        </div>

        {/* Right Column: AI Explanation */}
        <div className="lg:col-span-2">
          <div className="academic-card p-8 lg:p-10 border-t-4 border-t-primary">
            <div className="flex items-center gap-3 mb-8 pb-4 border-b border-border/50">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-2xl font-serif font-bold text-foreground">Cognix Analysis</h2>
                <p className="text-sm text-muted-foreground">AI-generated structured breakdown</p>
              </div>
            </div>

            <div className="prose-academic space-y-10">
              <section>
                <h3>Overview</h3>
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{paper.explanation.overview}</ReactMarkdown>
              </section>

              <section>
                <h3>Background & Context</h3>
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{paper.explanation.background}</ReactMarkdown>
              </section>

              <section>
                <h3>Key Concepts & Methodology</h3>
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{paper.explanation.keyConcepts}</ReactMarkdown>
              </section>

              <section>
                <h3>Applications & Implications</h3>
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{paper.explanation.applications}</ReactMarkdown>
              </section>

              {paper.explanation.references && (
                <section className="pt-6 mt-6 border-t border-border/50">
                  <h3 className="text-sm uppercase tracking-wider text-muted-foreground">References Context</h3>
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>{paper.explanation.references}</ReactMarkdown>
                </section>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
