import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useSessions, useCreateSession } from "@/hooks/use-chat";
import { useComparison } from "@/context/comparison-context";
import { motion, AnimatePresence } from "framer-motion";
import { 
  BookOpen, 
  MessageSquare, 
  LogOut, 
  Plus,
  Scale,
  X,
  ChevronRight
} from "lucide-react";

export function Layout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();
  const { data: sessions } = useSessions();
  const { selectedPapers, clearComparison } = useComparison();
  const createSession = useCreateSession();

  if (!user) return <>{children}</>;

  const handleNewChat = () => {
    createSession.mutate("New Research Session", {
      onSuccess: (data) => {
        setLocation(`/chat/${data.session.id}`);
      }
    });
  };

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden">
      {/* Sidebar */}
      <div className="w-72 border-r bg-card flex flex-col hidden md:flex shrink-0 shadow-sm z-10 relative">
        <div className="p-6 border-b border-border/50">
          <Link href="/" className="flex items-center gap-3 cursor-pointer group">
            <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center font-serif font-bold text-xl group-hover:scale-105 transition-transform shadow-md">
              C
            </div>
            <span className="font-serif font-semibold text-2xl tracking-tight">Cognix</span>
          </Link>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          <div>
            <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-2">
              Research
            </div>
            <Link href="/">
              <button className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${location === '/' ? 'bg-primary/10 text-primary' : 'text-foreground/80 hover:bg-muted hover:text-foreground'}`}>
                <BookOpen className="w-4 h-4" />
                Discovery Home
              </button>
            </Link>
            {selectedPapers.length > 0 && (
              <Link href="/compare">
                <button className={`mt-1 w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${location === '/compare' ? 'bg-primary/10 text-primary' : 'text-foreground/80 hover:bg-muted hover:text-foreground'}`}>
                  <Scale className="w-4 h-4" />
                  Compare Papers
                  <span className="ml-auto bg-primary text-primary-foreground text-[10px] px-2 py-0.5 rounded-full">
                    {selectedPapers.length}
                  </span>
                </button>
              </Link>
            )}
          </div>

          <div>
            <div className="flex items-center justify-between px-2 mb-3">
              <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Chat History
              </div>
              <button 
                onClick={handleNewChat}
                className="text-muted-foreground hover:text-primary transition-colors"
                title="New Chat"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
            <div className="space-y-1">
              {sessions?.map(session => (
                <Link key={session.id} href={`/chat/${session.id}`}>
                  <button className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors text-left truncate ${location === `/chat/${session.id}` ? 'bg-muted text-foreground font-medium' : 'text-foreground/70 hover:bg-muted/50 hover:text-foreground'}`}>
                    <MessageSquare className="w-4 h-4 shrink-0 opacity-50" />
                    <span className="truncate">{session.topic}</span>
                  </button>
                </Link>
              ))}
              {sessions?.length === 0 && (
                <p className="text-xs text-muted-foreground px-2 italic">No previous sessions</p>
              )}
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-border/50">
          <button 
            onClick={() => logout()}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-foreground/70 hover:bg-destructive/10 hover:text-destructive transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col relative overflow-hidden bg-background/50">
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>

        {/* Floating Comparison Bar */}
        <AnimatePresence>
          {selectedPapers.length >= 2 && location !== '/compare' && (
            <motion.div 
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              className="absolute bottom-6 left-1/2 -translate-x-1/2 z-50"
            >
              <div className="glass-panel rounded-full px-6 py-3 flex items-center gap-6 shadow-xl">
                <div className="flex items-center gap-2">
                  <div className="flex -space-x-2">
                    {selectedPapers.slice(0, 3).map((p, i) => (
                      <div key={p.paperId} className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xs font-medium border-2 border-white relative z-[1]" style={{ zIndex: 3-i }}>
                        {p.title.charAt(0)}
                      </div>
                    ))}
                  </div>
                  <span className="text-sm font-medium text-foreground">
                    {selectedPapers.length} papers selected
                  </span>
                </div>
                
                <div className="flex items-center gap-2 border-l border-border pl-6">
                  <button 
                    onClick={clearComparison}
                    className="text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Clear
                  </button>
                  <Link href="/compare">
                    <button className="px-5 py-2 bg-primary text-primary-foreground text-sm font-medium rounded-full shadow-md shadow-primary/20 hover:shadow-lg hover:-translate-y-0.5 transition-all flex items-center gap-2">
                      Compare Now <ChevronRight className="w-4 h-4" />
                    </button>
                  </Link>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
