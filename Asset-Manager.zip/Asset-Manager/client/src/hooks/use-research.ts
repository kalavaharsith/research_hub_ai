import { useQuery, useMutation } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { PaperData, PaperDetail, CompareResponse } from "@shared/schema";

export function useSearch(query: string) {
  return useQuery({
    queryKey: [api.research.search.path, query],
    queryFn: async () => {
      if (!query) return [];
      const url = new URL(api.research.search.path, window.location.origin);
      url.searchParams.set("query", query);
      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Search failed");
      return res.json() as Promise<PaperData[]>;
    },
    enabled: query.trim().length > 0,
  });
}

export function usePaper(id: string) {
  return useQuery({
    queryKey: [api.research.paper.path, id],
    queryFn: async () => {
      const url = buildUrl(api.research.paper.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) {
        if (res.status === 404) throw new Error("Paper not found");
        throw new Error("Failed to load paper");
      }
      return res.json() as Promise<PaperDetail>;
    },
    enabled: !!id,
  });
}

export function useCompare() {
  return useMutation({
    mutationFn: async (paperIds: string[]) => {
      const res = await fetch(api.research.compare.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paperIds }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Comparison failed");
      return res.json() as Promise<CompareResponse>;
    },
  });
}
