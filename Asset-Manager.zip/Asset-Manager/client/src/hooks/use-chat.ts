import { useState, useRef, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { ChatSession, ChatMessage } from "@shared/schema";

export function useSessions() {
  return useQuery({
    queryKey: [api.chat.getSessions.path],
    queryFn: async () => {
      const res = await fetch(api.chat.getSessions.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch sessions");
      return res.json() as Promise<ChatSession[]>;
    },
  });
}

export function useSession(id: number) {
  return useQuery({
    queryKey: [api.chat.getSession.path, id],
    queryFn: async () => {
      const url = buildUrl(api.chat.getSession.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to load session");
      return res.json() as Promise<{ session: ChatSession; messages: ChatMessage[] }>;
    },
    enabled: !!id,
  });
}

export function useCreateSession() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (message: string) => {
      const res = await fetch(api.chat.createSession.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create session");
      return res.json() as Promise<{ session: ChatSession }>;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.chat.getSessions.path] });
    },
  });
}

export function useChatStream(sessionId: number) {
  const queryClient = useQueryClient();
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");
  const [error, setError] = useState<string | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const sendMessage = useCallback(async (message: string) => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    abortControllerRef.current = new AbortController();
    
    setIsStreaming(true);
    setStreamingContent("");
    setError(null);

    // Optimistically add user message to cache
    queryClient.setQueryData(
      [api.chat.getSession.path, sessionId],
      (old: any) => {
        if (!old) return old;
        return {
          ...old,
          messages: [
            ...old.messages,
            { id: Date.now(), sessionId, role: 'user', content: message, createdAt: new Date() }
          ]
        };
      }
    );

    try {
      const url = buildUrl(api.chat.sendMessage.path, { id: sessionId });
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
        credentials: "include",
        signal: abortControllerRef.current.signal,
      });

      if (!res.ok) throw new Error("Failed to send message");
      
      const reader = res.body?.getReader();
      if (!reader) throw new Error("No response stream");
      
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const dataStr = line.slice(6);
          if (!dataStr.trim()) continue;

          try {
            const data = JSON.parse(dataStr);
            if (data.done) {
              break;
            } else if (data.content) {
              setStreamingContent((prev) => prev + data.content);
            } else if (data.error) {
              setError(data.error);
            }
          } catch (e) {
            console.error("Failed to parse SSE chunk", e);
          }
        }
      }
      
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setError(err.message || "Something went wrong");
      }
    } finally {
      setIsStreaming(false);
      abortControllerRef.current = null;
      // Refresh to get actual DB saved messages
      queryClient.invalidateQueries({ queryKey: [api.chat.getSession.path, sessionId] });
    }
  }, [sessionId, queryClient]);

  return { sendMessage, isStreaming, streamingContent, error };
}
