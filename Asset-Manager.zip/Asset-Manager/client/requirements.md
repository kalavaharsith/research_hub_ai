## Packages
react-markdown | Rendering academic text and chat responses
remark-gfm | GitHub flavored markdown for tables/lists
framer-motion | Page transitions and scroll-triggered animations

## Notes
- We assume `@shared/routes` exports the `api` object and `buildUrl` function as defined in the routes_manifest.
- We assume `@shared/schema` exports types like `PaperData`, `PaperDetail`, `CompareResponse`, `ChatSession`, `ChatMessage`, etc.
- The chat SSE endpoint returns chunks in the format `data: {"content": "..."}` and terminates with `data: {"done": true}`.
