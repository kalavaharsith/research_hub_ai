import { z } from 'zod';
import { insertUserSchema, users } from './schema';

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  internal: z.object({ message: z.string() }),
  unauthorized: z.object({ message: z.string() }),
  notFound: z.object({ message: z.string() }),
};

export const api = {
  auth: {
    login: {
      method: 'POST' as const,
      path: '/api/auth/login' as const,
      input: insertUserSchema,
      responses: { 200: z.custom<{id: string; username: string}>(), 401: errorSchemas.unauthorized }
    },
    signup: {
      method: 'POST' as const,
      path: '/api/auth/signup' as const,
      input: insertUserSchema,
      responses: { 201: z.custom<{id: string; username: string}>(), 400: errorSchemas.validation }
    },
    logout: {
      method: 'POST' as const,
      path: '/api/auth/logout' as const,
      responses: { 200: z.object({ message: z.string() }) }
    },
    me: {
      method: 'GET' as const,
      path: '/api/auth/me' as const,
      responses: { 200: z.custom<{id: string; username: string}>(), 401: errorSchemas.unauthorized }
    }
  },
  research: {
    search: {
      method: 'GET' as const,
      path: '/api/search' as const,
      input: z.object({ query: z.string() }),
      responses: { 200: z.array(z.any()) }
    },
    paper: {
      method: 'GET' as const,
      path: '/api/paper/:id' as const,
      responses: { 200: z.any(), 404: errorSchemas.notFound }
    },
    compare: {
      method: 'POST' as const,
      path: '/api/compare' as const,
      input: z.object({ paperIds: z.array(z.string()) }),
      responses: { 200: z.any() } // CompareResponse
    }
  },
  chat: {
    getSessions: {
      method: 'GET' as const,
      path: '/api/chat/sessions' as const,
      responses: { 200: z.array(z.any()) }
    },
    createSession: {
      method: 'POST' as const,
      path: '/api/chat/sessions' as const,
      input: z.object({ message: z.string() }),
      responses: { 201: z.any() }
    },
    getSession: {
      method: 'GET' as const,
      path: '/api/chat/sessions/:id' as const,
      responses: { 200: z.object({ session: z.any(), messages: z.array(z.any()) }) }
    },
    sendMessage: {
      method: 'POST' as const,
      path: '/api/chat/sessions/:id/messages' as const,
      input: z.object({ message: z.string() }),
      responses: { 200: z.any() }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
