import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { searchPapers, getPaperDetails, generatePaperExplanation, generateComparison } from "./research";
import OpenAI from "openai";
import session from "express-session";
import MemoryStoreFactory from "memorystore";

const MemoryStore = MemoryStoreFactory(session);

const openAiClient = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.use(
    session({
      store: new MemoryStore({ checkPeriod: 86400000 }),
      secret: process.env.SESSION_SECRET || "cognix_secret",
      resave: false,
      saveUninitialized: false,
    })
  );

  // Auth Routes
  app.post(api.auth.login.path, async (req, res) => {
    try {
      const input = api.auth.login.input.parse(req.body);
      const user = await storage.getUserByUsername(input.username);
      if (!user || user.password !== input.password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      (req.session as any).userId = user.id;
      res.status(200).json({ id: user.id, username: user.username });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.auth.signup.path, async (req, res) => {
    try {
      const input = api.auth.signup.input.parse(req.body);
      const existing = await storage.getUserByUsername(input.username);
      if (existing) {
        return res.status(400).json({ message: "Username taken" });
      }
      const user = await storage.createUser(input);
      (req.session as any).userId = user.id;
      res.status(201).json({ id: user.id, username: user.username });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.auth.logout.path, (req, res) => {
    req.session.destroy(() => {
      res.status(200).json({ message: "Logged out" });
    });
  });

  app.get(api.auth.me.path, async (req, res) => {
    const userId = (req.session as any).userId;
    if (!userId) return res.status(401).json({ message: "Not logged in" });
    const user = await storage.getUser(userId);
    if (!user) return res.status(401).json({ message: "User not found" });
    res.status(200).json({ id: user.id, username: user.username });
  });

  // Auth Middleware for API routes
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.userId) return res.status(401).json({ message: "Unauthorized" });
    next();
  };

  // Research Routes
  app.get(api.research.search.path, requireAuth, async (req, res) => {
    const query = req.query.query as string;
    if (!query) return res.status(200).json([]);
    const results = await searchPapers(query);
    res.status(200).json(results);
  });

  app.get(api.research.paper.path, requireAuth, async (req, res) => {
    try {
      const paperData = await getPaperDetails(req.params.id);
      const explanation = await generatePaperExplanation(openAiClient, paperData.title, paperData.abstract);
      
      const detail = {
        ...paperData,
        keywords: explanation.keyConcepts ? explanation.keyConcepts.split(',').map((k:string)=>k.trim()) : [],
        explanation
      };
      res.status(200).json(detail);
    } catch (error) {
      res.status(404).json({ message: "Paper not found or error fetching details" });
    }
  });

  app.post(api.research.compare.path, requireAuth, async (req, res) => {
    try {
      const { paperIds } = api.research.compare.input.parse(req.body);
      const papersData = await Promise.all(paperIds.map(id => getPaperDetails(id)));
      
      const compRes = await generateComparison(openAiClient, papersData);
      
      // Combine with original data
      const finalComparison = papersData.map((p, i) => ({
        title: p.title,
        authors: p.authors,
        year: p.year,
        keyIdea: compRes.papers?.[i]?.keyIdea || "",
        methodology: compRes.papers?.[i]?.methodology || "",
        conclusion: compRes.papers?.[i]?.conclusion || ""
      }));
      
      res.status(200).json({ papers: finalComparison });
    } catch (err) {
      res.status(500).json({ message: "Comparison failed" });
    }
  });

  // Chat Routes
  app.get(api.chat.getSessions.path, requireAuth, async (req, res) => {
    const sessions = await storage.getChatSessions((req.session as any).userId);
    res.status(200).json(sessions);
  });

  app.post(api.chat.createSession.path, requireAuth, async (req, res) => {
    try {
      const { message } = api.chat.createSession.input.parse(req.body);
      
      const topicRes = await openAiClient.chat.completions.create({
        model: "gpt-5.1",
        messages: [{ role: "user", content: `Generate a 3-5 word topic for this research query: ${message}` }],
      });
      const topic = topicRes.choices[0]?.message?.content?.replace(/["']/g, '') || "New Research Chat";
      
      const session = await storage.createChatSession({
        userId: (req.session as any).userId,
        topic
      });
      
      await storage.createChatMessage({
        sessionId: session.id,
        role: 'user',
        content: message
      });
      
      res.status(201).json({ session });
    } catch (err) {
      res.status(500).json({ message: "Failed to create session" });
    }
  });

  app.get(api.chat.getSession.path, requireAuth, async (req, res) => {
    const sessionId = parseInt(req.params.id);
    const session = await storage.getChatSession(sessionId);
    if (!session || session.userId !== (req.session as any).userId) {
      return res.status(404).json({ message: "Not found" });
    }
    const messages = await storage.getChatMessages(sessionId);
    res.status(200).json({ session, messages });
  });

  app.post(api.chat.sendMessage.path, requireAuth, async (req, res) => {
    const sessionId = parseInt(req.params.id);
    const session = await storage.getChatSession(sessionId);
    if (!session || session.userId !== (req.session as any).userId) {
      return res.status(404).json({ message: "Not found" });
    }

    const { message } = api.chat.sendMessage.input.parse(req.body);
    await storage.createChatMessage({ sessionId, role: 'user', content: message });

    const messages = await storage.getChatMessages(sessionId);
    const chatHistory = messages.map(m => ({ role: m.role as "user" | "assistant", content: m.content }));

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const systemPrompt = "You are a research assistant for the Cognix platform. Answer only research-related questions. Provide structured, factual, academic-style responses. Do not engage in casual conversation. Cite relevant concepts.";
    
    try {
      const stream = await openAiClient.chat.completions.create({
        model: "gpt-5.1",
        messages: [{ role: "system", content: systemPrompt }, ...chatHistory],
        stream: true
      });

      let fullContent = "";
      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || "";
        if (content) {
          fullContent += content;
          res.write(`data: ${JSON.stringify({ content })}\n\n`);
        }
      }

      await storage.createChatMessage({ sessionId, role: 'assistant', content: fullContent });
      res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
      res.end();
    } catch (err) {
      console.error(err);
      res.write(`data: ${JSON.stringify({ error: "Failed to stream response" })}\n\n`);
      res.end();
    }
  });

  return httpServer;
}
