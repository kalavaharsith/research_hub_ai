import { PaperData } from '@shared/schema';

export async function searchPapers(topic: string): Promise<PaperData[]> {
  try {
    const response = await fetch(`https://api.semanticscholar.org/graph/v1/paper/search?query=${encodeURIComponent(topic)}&fields=title,authors,year,abstract,externalIds,url,openAccessPdf&limit=10`);
    if (!response.ok) throw new Error('Semantic Scholar API error');
    const data = await response.json();
    
    if (data && data.data) {
      return data.data.map((p: any) => ({
        paperId: p.paperId,
        title: p.title || 'Untitled',
        authors: p.authors ? p.authors.map((a: any) => a.name) : [],
        year: p.year || new Date().getFullYear(),
        abstract: p.abstract || 'No abstract available.',
        url: p.url || (p.openAccessPdf ? p.openAccessPdf.url : `https://api.semanticscholar.org/CorpusID:${p.externalIds?.CorpusId}`)
      }));
    }
  } catch (error) {
    console.error('Semantic Scholar API failed, falling back to arXiv', error);
  }

  try {
    const response = await fetch(`https://export.arxiv.org/api/query?search_query=all:${encodeURIComponent(topic)}&start=0&max_results=10`);
    const xml = await response.text();
    
    const entries = xml.match(/<entry>[\s\S]*?<\/entry>/g) || [];
    return entries.map(entry => {
      const idMatch = entry.match(/<id>(.*?)<\/id>/);
      const titleMatch = entry.match(/<title>([\s\S]*?)<\/title>/);
      const abstractMatch = entry.match(/<summary>([\s\S]*?)<\/summary>/);
      const yearMatch = entry.match(/<published>(\d{4})-[^<]*<\/published>/);
      
      const authorMatches = [...entry.matchAll(/<author>\s*<name>(.*?)<\/name>\s*<\/author>/g)];
      const authors = authorMatches.map(m => m[1]);
      
      const url = idMatch ? idMatch[1].trim() : '';
      const paperId = url.split('/').pop() || Math.random().toString();
      
      return {
        paperId,
        title: titleMatch ? titleMatch[1].replace(/\n/g, ' ').trim() : 'Untitled',
        authors,
        year: yearMatch ? parseInt(yearMatch[1], 10) : new Date().getFullYear(),
        abstract: abstractMatch ? abstractMatch[1].trim() : 'No abstract available.',
        url
      };
    });
  } catch (error) {
    console.error('arXiv fallback failed', error);
    return [];
  }
}

export async function getPaperDetails(paperId: string): Promise<any> {
  if (/^[0-9a-f]{40}$/i.test(paperId)) {
    const response = await fetch(`https://api.semanticscholar.org/graph/v1/paper/${paperId}?fields=title,authors,year,abstract,url,openAccessPdf`);
    if (response.ok) {
      const p = await response.json();
      return {
        paperId: p.paperId,
        title: p.title || 'Untitled',
        authors: p.authors ? p.authors.map((a: any) => a.name) : [],
        year: p.year || new Date().getFullYear(),
        abstract: p.abstract || 'No abstract available.',
        url: p.url || (p.openAccessPdf ? p.openAccessPdf.url : '')
      };
    }
  }
  
  const response = await fetch(`https://export.arxiv.org/api/query?id_list=${paperId}`);
  const xml = await response.text();
  const entry = xml.match(/<entry>[\s\S]*?<\/entry>/);
  if (entry) {
    const e = entry[0];
    const idMatch = e.match(/<id>(.*?)<\/id>/);
    const titleMatch = e.match(/<title>([\s\S]*?)<\/title>/);
    const abstractMatch = e.match(/<summary>([\s\S]*?)<\/summary>/);
    const yearMatch = e.match(/<published>(\d{4})-[^<]*<\/published>/);
    const authorMatches = [...e.matchAll(/<author>\s*<name>(.*?)<\/name>\s*<\/author>/g)];
    const url = idMatch ? idMatch[1].trim() : '';
    
    return {
      paperId,
      title: titleMatch ? titleMatch[1].replace(/\n/g, ' ').trim() : 'Untitled',
      authors: authorMatches.map(m => m[1]),
      year: yearMatch ? parseInt(yearMatch[1], 10) : new Date().getFullYear(),
      abstract: abstractMatch ? abstractMatch[1].trim() : 'No abstract available.',
      url
    };
  }
  
  throw new Error("Paper not found");
}

export async function generatePaperExplanation(openAiClient: any, title: string, abstract: string) {
  const prompt = `You are a research assistant. Generate a structured Wikipedia-style explanation for this academic paper.
Title: ${title}
Abstract: ${abstract}

Output ONLY a JSON object with these EXACT keys:
{
  "overview": "string",
  "background": "string",
  "keyConcepts": "string",
  "applications": "string",
  "references": "string"
}`;

  const response = await openAiClient.chat.completions.create({
    model: "gpt-5.1",
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" }
  });

  return JSON.parse(response.choices[0]?.message?.content || "{}");
}

export async function generateComparison(openAiClient: any, papers: any[]) {
  const prompt = `You are a research assistant. Compare the following papers.
${papers.map(p => `Title: ${p.title}\nAbstract: ${p.abstract}`).join('\n\n')}

Output ONLY a JSON object with a single key "papers" containing an array of objects in the EXACT same order.
Each object must have these EXACT keys:
{
  "keyIdea": "string",
  "methodology": "string",
  "conclusion": "string"
}`;

  const response = await openAiClient.chat.completions.create({
    model: "gpt-5.1",
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" }
  });

  return JSON.parse(response.choices[0]?.message?.content || '{"papers": []}');
}
